package com.example.kotlnstates

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class ScreenContent(
    val id:Int,
    @DrawableRes val image:Int,
    @StringRes val content:Int
)

