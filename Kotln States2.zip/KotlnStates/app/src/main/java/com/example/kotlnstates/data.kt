package com.example.kotlnstates
 val screenData= listOf(
     ScreenContent(1, R.drawable.car2, R.string.car1),
     ScreenContent(2, R.drawable.black_car_hd_brabus_s_class_mpule1gupdg4ohr0, R.string.car2),
     ScreenContent(3, R.drawable.black_car_hd_ferrari_42p5pzpxl5na0cmh, R.string.car3),

 )
fun goNext(){}