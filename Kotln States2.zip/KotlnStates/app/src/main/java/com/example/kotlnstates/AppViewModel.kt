package com.example.kotlnstates


import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class AppViewModel{

    var appState by mutableStateOf(AppState())
        private set

    var index = 0

    fun goNext(){
        if (!checkIfRestartClicked(index)){
            index++
            appState = AppState(content = screenData[index])
        }else{
            index = 0
            appState = AppState()
        }


    }

    private fun checkIfRestartClicked(index:Int):Boolean { return index == screenData.size - 1}

    fun Int.checkIfRestart() :Boolean { return this == screenData.size - 1}



}

data class AppState(
    val content: ScreenContent = screenData[0]
)